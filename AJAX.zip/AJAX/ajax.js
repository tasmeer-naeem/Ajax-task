console.log("ajax tutorial")

let fetchbtnvar=document.getElementById('fetchbtn');
fetchbtnvar.addEventListener('click',buttonClickHandler);

function buttonClickHandler(){
    console.log("Clicked fetch button");

    const xhr = new XMLHttpRequest();
    //xhr.open('GET','https://jsonplaceholder.typicode.com/todos/1',true);
    xhr.open('POST','http://dummy.restapiexample.com/api/v1/create',true);
    xhr.getResponseHeader('content-type','application/json');

    xhr.onprogress=function(){
        console.log("on progress")
    }
    //xhr.onreadystatechange=function(){
    ///    console.log("ready state",this.readyState)
    //}
    xhr.onload=function(){
        if(this.status===200){
            console.log(this.responseText)
        }
        else{
            console.log("some error occured")
        }
        
    }
    params='{"name":"test","salary":"123","age":"23"}';
    xhr.send(params);
    console.log("we are done ! ");
}

 

 let backupbtnvar=document.getElementById('backupbtn');
 backupbtnvar.addEventListener('click',backupClickHandler);
 
 function backupClickHandler(){
    console.log("Clicked backup button");

    const xhr = new XMLHttpRequest();
    xhr.open('GET','https://dummy.restapiexample.com/api/v1/employees',true);
    //xhr.open('POST','http://dummy.restapiexample.com/api/v1/create',true);
    //xhr.getResponseHeader('content-type','application/json');

    //xhr.onprogress=function(){
    //    console.log("on progress")
    //}
    //xhr.onreadystatechange=function(){
    ///    console.log("ready state",this.readyState)
    //}
    xhr.onload=function(){
        if(this.status===200)
        {
            let obj=JSON.parse(this.responseText);
            console.log(obj);

            let listt=document.getElementById('list')
            str=""
            for (key in obj)
            {
                str +=`<li>${obj[key].employee_name} </li>`
            }
            listt.innerHTML=str;
        }
        else{
            console.log("some error occured")
        }
        
    }
    //params='{"name":"test","salary":"123","age":"23"}';
    xhr.send();
    console.log("we are fetching employees ! ");
}


